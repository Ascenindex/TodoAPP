document.addEventListener('DOMContentLoaded', loadTasks);

function sendTaskForm(event) {
  event.preventDefault(); // Impede o comportamento padrão do formulário
  
  let inputTask = document.getElementById('inputTask');
  let taskList = document.getElementById('taskList');
  
  if (inputTask.value.trim() !== "") {
    let listItem = createTaskItem(inputTask.value);
    
    taskList.appendChild(listItem);
    saveTask(inputTask.value);
    
    inputTask.value = ""; // Limpa o campo de input
    inputTask.focus();
  }
}

function createTaskItem(taskText) {
  let listItem = document.createElement('li');
  listItem.textContent = taskText;
  
  let deleteIcon = document.createElement('i');
  deleteIcon.classList.add('fa-solid', 'fa-trash');
  deleteIcon.onclick = function() {
    let taskList = document.getElementById('taskList');
    taskList.removeChild(listItem);
    removeTask(taskText);
  };

  listItem.appendChild(deleteIcon);
  return listItem;
}

function saveTask(task) {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  tasks.push(task);
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

function loadTasks() {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  let taskList = document.getElementById('taskList');
  tasks.forEach(task => {
    let listItem = createTaskItem(task);
    taskList.appendChild(listItem);
  });
}

function removeTask(task) {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  tasks = tasks.filter(t => t !== task);
  localStorage.setItem('tasks', JSON.stringify(tasks));
}
